# Photo Booth (Android)

Minimal black & white photobooth. Take up to 4 portraits with a 3-2-1 countdown;
each is developed in grainy B&W, then stitched into a photobooth strip.

Stack: Kotlin, Jetpack Compose, CameraX. minSdk 29.

## Build the APK with GitHub Actions
1. Create a new GitHub repo and push this folder's contents (keep the `.github` folder).
2. Open the **Actions** tab -> **Build APK** (runs on every push, or press *Run workflow*).
3. When it finishes, download the **PhotoBooth-apk** artifact -> unzip -> install `app-debug.apk`.

## Build locally
Open the folder in Android Studio (Koala or newer) and press Run.
