package com.unclem.photobooth

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

object Store {
    private fun dir(ctx: Context, name: String): File =
        File(ctx.filesDir, name).apply { mkdirs() }

    private fun list(d: File): List<File> =
        d.listFiles()?.filter { it.extension == "jpg" }?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    fun shots(ctx: Context): List<File> = list(dir(ctx, "shots"))
    fun prints(ctx: Context): List<File> = list(dir(ctx, "prints"))

    private fun writeJpeg(bmp: Bitmap, file: File, quality: Int) {
        file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
    }

    /** Saves each shot and the stitched strip. Returns the strip file. */
    fun saveSession(ctx: Context, photos: List<Bitmap>): File {
        val stamp = System.currentTimeMillis()
        val shotsDir = dir(ctx, "shots")
        photos.forEachIndexed { i, b ->
            writeJpeg(b, File(shotsDir, "shot_${stamp}_${i + 1}.jpg"), 92)
        }
        val date = SimpleDateFormat("dd . MM . yyyy", Locale.getDefault()).format(Date(stamp))
        val strip = Strip.compose(photos, date)
        val out = File(dir(ctx, "prints"), "strip_$stamp.jpg")
        writeJpeg(strip, out, 94)
        strip.recycle()
        return out
    }

    fun exportToGallery(ctx: Context, file: File): Boolean {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, file.name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/PhotoBooth"
                )
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            resolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun share(ctx: Context, file: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Share"))
    }
}

fun decodeSampled(file: File, maxDim: Int): android.graphics.Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.path, bounds)
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxDim) sample *= 2
    return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
}

@Composable
fun rememberFileBitmap(file: File, maxDim: Int): ImageBitmap? =
    produceState<ImageBitmap?>(initialValue = null, file, maxDim) {
        value = withContext(Dispatchers.IO) { decodeSampled(file, maxDim)?.asImageBitmap() }
    }.value
