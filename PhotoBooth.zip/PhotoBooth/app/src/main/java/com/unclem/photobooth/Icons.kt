package com.unclem.photobooth

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

@Composable
private fun LineIcon(
    size: Dp,
    weight: Dp,
    draw: DrawScope.(Float, Stroke) -> Unit
) {
    Canvas(Modifier.size(size)) {
        val u = this.size.minDimension / 24f
        val st = Stroke(width = weight.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        this.draw(u, st)
    }
}

@Composable
fun CameraIcon(color: Color, size: Dp = 26.dp, weight: Dp = 1.7.dp) =
    LineIcon(size, weight) { u, st ->
        drawRoundRect(color, Offset(2f * u, 7f * u), Size(20f * u, 13f * u), CornerRadius(3.2f * u), style = st)
        val bump = Path().apply {
            moveTo(8f * u, 7f * u); lineTo(9.6f * u, 4f * u); lineTo(14.4f * u, 4f * u); lineTo(16f * u, 7f * u)
        }
        drawPath(bump, color, style = st)
        drawCircle(color, 3.6f * u, Offset(12f * u, 13.5f * u), style = st)
    }

@Composable
fun GalleryIcon(color: Color, size: Dp = 22.dp, weight: Dp = 1.6.dp) =
    LineIcon(size, weight) { u, st ->
        drawRoundRect(color, Offset(3f * u, 3f * u), Size(18f * u, 18f * u), CornerRadius(4f * u), style = st)
        drawCircle(color, 1.6f * u, Offset(9f * u, 9f * u), style = st)
        val m = Path().apply {
            moveTo(3.5f * u, 17f * u); lineTo(9f * u, 12.5f * u); lineTo(13f * u, 16f * u)
            lineTo(16f * u, 13.5f * u); lineTo(20.5f * u, 17.5f * u)
        }
        drawPath(m, color, style = st)
    }

@Composable
fun StarIcon(color: Color, size: Dp = 22.dp, weight: Dp = 1.6.dp) =
    LineIcon(size, weight) { u, st ->
        val p = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) 9.5f else 4.2f
            val a = Math.toRadians(-90.0 + i * 36.0)
            val x = (12f + r * cos(a).toFloat()) * u
            val y = (12.5f + r * sin(a).toFloat()) * u
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        drawPath(p, color, style = st)
    }

@Composable
fun FlipIcon(color: Color, size: Dp = 20.dp, weight: Dp = 1.6.dp) =
    LineIcon(size, weight) { u, st ->
        drawArc(
            color, startAngle = -60f, sweepAngle = 270f, useCenter = false,
            topLeft = Offset(5f * u, 5f * u), size = Size(14f * u, 14f * u), style = st
        )
        val tip = Offset(12f * u + 7f * u * cos(Math.toRadians(210.0)).toFloat(),
            12f * u + 7f * u * sin(Math.toRadians(210.0)).toFloat())
        val dir = Offset(0.5f, -0.866f)
        val back = Offset(-dir.x * 3.4f * u, -dir.y * 3.4f * u)
        fun rot(v: Offset, deg: Double): Offset {
            val r = Math.toRadians(deg)
            val c = cos(r).toFloat()
            val s = sin(r).toFloat()
            return Offset(v.x * c - v.y * s, v.x * s + v.y * c)
        }
        drawLine(color, tip, tip + rot(back, 40.0), strokeWidth = st.width, cap = StrokeCap.Round)
        drawLine(color, tip, tip + rot(back, -40.0), strokeWidth = st.width, cap = StrokeCap.Round)
    }

@Composable
fun CloseIcon(color: Color, size: Dp = 18.dp, weight: Dp = 1.8.dp) =
    LineIcon(size, weight) { u, st ->
        drawLine(color, Offset(6f * u, 6f * u), Offset(18f * u, 18f * u), strokeWidth = st.width, cap = StrokeCap.Round)
        drawLine(color, Offset(18f * u, 6f * u), Offset(6f * u, 18f * u), strokeWidth = st.width, cap = StrokeCap.Round)
    }

@Composable
fun ChevronIcon(color: Color, size: Dp = 16.dp, left: Boolean = false, weight: Dp = 2.dp) =
    LineIcon(size, weight) { u, st ->
        val p = Path().apply {
            if (left) {
                moveTo(15f * u, 5f * u); lineTo(8f * u, 12f * u); lineTo(15f * u, 19f * u)
            } else {
                moveTo(9f * u, 5f * u); lineTo(16f * u, 12f * u); lineTo(9f * u, 19f * u)
            }
        }
        drawPath(p, color, style = st)
    }

@Composable
fun PersonIcon(color: Color, size: Dp = 20.dp, weight: Dp = 1.6.dp) =
    LineIcon(size, weight) { u, st ->
        drawCircle(color, 3.6f * u, Offset(12f * u, 8.5f * u), style = st)
        val p = Path().apply {
            moveTo(5f * u, 20f * u)
            cubicTo(5f * u, 15.5f * u, 8f * u, 14f * u, 12f * u, 14f * u)
            cubicTo(16f * u, 14f * u, 19f * u, 15.5f * u, 19f * u, 20f * u)
        }
        drawPath(p, color, style = st)
    }

@Composable
fun TrashIcon(color: Color, size: Dp = 20.dp, weight: Dp = 1.6.dp) =
    LineIcon(size, weight) { u, st ->
        drawLine(color, Offset(5f * u, 7f * u), Offset(19f * u, 7f * u), strokeWidth = st.width, cap = StrokeCap.Round)
        val lid = Path().apply {
            moveTo(10f * u, 7f * u); lineTo(10f * u, 4f * u); lineTo(14f * u, 4f * u); lineTo(14f * u, 7f * u)
        }
        drawPath(lid, color, style = st)
        val can = Path().apply {
            moveTo(7f * u, 7f * u); lineTo(8f * u, 20f * u); lineTo(16f * u, 20f * u); lineTo(17f * u, 7f * u)
        }
        drawPath(can, color, style = st)
    }
