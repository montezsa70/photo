package com.unclem.photobooth

import android.graphics.Bitmap
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun SessionScreen(
    holder: CameraHolder,
    front: Boolean,
    onClose: () -> Unit,
    onDone: (File) -> Unit
) {
    StatusBarIcons(darkIcons = false)
    val context = LocalContext.current
    val total = 4
    val photos = remember { mutableStateListOf<Bitmap>() }
    var label by remember { mutableStateOf("READY") }
    var big by remember { mutableStateOf("") }
    var hint by remember { mutableStateOf("") }
    var flash by remember { mutableStateOf(false) }
    var finishing by remember { mutableStateOf(false) }

    LaunchedEffect(finishing) {
        if (finishing) {
            label = "DEVELOPING"; big = ""; hint = ""
            val list = photos.toList()
            if (list.isEmpty()) {
                onClose()
                return@LaunchedEffect
            }
            val file = withContext(Dispatchers.Default) { Store.saveSession(context, list) }
            onDone(file)
        } else {
            delay(900)
            for (i in 0 until total) {
                label = if (i == 0) "READY" else "SHOT ${i + 1} OF $total"
                hint = "Keep still"
                for (c in 3 downTo 1) {
                    big = c.toString()
                    delay(1000)
                }
                big = ""; hint = ""
                flash = true
                val developed = try {
                    val raw = holder.imageCapture.takeBitmap(holder.executor)
                    withContext(Dispatchers.Default) {
                        Booth.develop(raw, front).also { raw.recycle() }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    null
                }
                if (developed != null) photos.add(developed)
                delay(120)
                flash = false
                label = "GOT IT"
                delay(900)
            }
            finishing = true
        }
    }

    val flashAlpha by animateFloatAsState(
        if (flash) 0.85f else 0f,
        tween(if (flash) 40 else 320),
        label = "flash"
    )

    Box(Modifier.fillMaxSize().background(Ink.Smoke)) {
        CameraPreview(holder, front, Modifier.fillMaxSize(), monochrome = true)
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.35f), Color.Black.copy(alpha = 0.10f), Color.Black.copy(alpha = 0.55f))
                )
            )
        )

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
                RoundButton(
                    size = 40.dp,
                    background = Color.Black.copy(alpha = 0.35f),
                    onClick = onClose
                ) { CloseIcon(Color.White, 16.dp) }
            }

            BoxWithConstraints(
                Modifier.weight(1f).fillMaxWidth().padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                val w = minOf(maxWidth * 0.66f, maxHeight * 0.7f)
                val h = w / 0.7f
                Box(
                    Modifier
                        .size(w, h)
                        .border(1.dp, Color.White.copy(alpha = 0.85f), RoundedCornerShape(50))
                ) {
                    Column(
                        Modifier.fillMaxSize().padding(vertical = 22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(5.dp).clip(CircleShape).background(Color.White))
                        Spacer(Modifier.height(10.dp))
                        Text(
                            label, fontSize = 10.sp, letterSpacing = 1.6.sp,
                            color = Color.White.copy(alpha = 0.75f), fontWeight = FontWeight.Medium
                        )
                        Spacer(Modifier.weight(1f))
                        Box(Modifier.height(130.dp), contentAlignment = Alignment.Center) {
                            Crossfade(targetState = big, animationSpec = tween(160), label = "num") { n ->
                                Text(
                                    n, color = Color.White, fontSize = 112.sp,
                                    fontWeight = FontWeight.ExtraLight, letterSpacing = 0.sp
                                )
                            }
                        }
                        Box(Modifier.height(18.dp), contentAlignment = Alignment.Center) {
                            Text(hint, fontSize = 12.sp, color = Color.White, letterSpacing = 0.sp)
                        }
                        Spacer(Modifier.weight(1.2f))
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(total) { i ->
                    val c = when {
                        i < photos.size -> Color.White
                        i == photos.size -> Color.White.copy(alpha = 0.45f)
                        else -> Color.White.copy(alpha = 0.2f)
                    }
                    Box(Modifier.width(38.dp).height(2.dp).clip(CircleShape).background(c))
                }
            }
            Spacer(Modifier.height(16.dp))

            Column(
                Modifier
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 12.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xFF1E1D1B).copy(alpha = 0.72f))
                    .padding(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeat(total) { i ->
                        Box(
                            Modifier
                                .weight(1f)
                                .aspectRatio(0.82f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.08f))
                        ) {
                            if (i < photos.size) {
                                val bmp = remember(photos[i]) { photos[i].asImageBitmap() }
                                Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.10f))
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Text(
                            if (photos.size == 1) "1 photo" else "${photos.size} photos",
                            fontSize = 12.sp, color = Color.White, letterSpacing = 0.sp
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Row(
                        Modifier
                            .tap(enabled = photos.isNotEmpty()) { finishing = true }
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = if (photos.isNotEmpty()) 0.16f else 0.07f))
                            .padding(start = 16.dp, end = 10.dp, top = 9.dp, bottom = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "View", fontSize = 12.sp, letterSpacing = 0.sp,
                            color = Color.White.copy(alpha = if (photos.isNotEmpty()) 1f else 0.4f)
                        )
                        Spacer(Modifier.width(6.dp))
                        ChevronIcon(Color.White.copy(alpha = if (photos.isNotEmpty()) 1f else 0.4f), 14.dp)
                    }
                }
            }
        }

        Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = flashAlpha)))
    }
}
