package com.unclem.photobooth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(
    holder: CameraHolder,
    front: Boolean,
    granted: Boolean,
    onFlip: () -> Unit,
    onAsk: () -> Unit,
    onShutter: () -> Unit,
    onGallery: () -> Unit,
    onPrints: () -> Unit
) {
    StatusBarIcons(darkIcons = true)

    Column(
        Modifier
            .fillMaxSize()
            .background(Ink.Paper)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(Ink.Black))
            Spacer(Modifier.width(8.dp))
            Text("PHOTO BOOTH", fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp, color = Ink.Black)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(Ink.Smoke),
                contentAlignment = Alignment.Center
            ) { PersonIcon(Color(0xFFBDB9B3), 20.dp) }
        }

        Spacer(Modifier.height(26.dp))

        Text(
            buildAnnotatedString {
                append("Make\nyour moment\n")
                withStyle(SpanStyle(color = Ink.Muted)) { append("count") }
            },
            fontSize = 34.sp,
            lineHeight = 36.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = (-1).sp,
            color = Ink.Black
        )

        Spacer(Modifier.height(20.dp))

        Box(Modifier.weight(1f).fillMaxWidth().padding(bottom = 8.dp)) {
            // viewfinder card
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(bottom = 44.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFFE4E1DC))
            ) {
                if (granted) {
                    CameraPreview(holder, front, Modifier.fillMaxSize(), monochrome = true)
                } else {
                    Column(
                        Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("Camera access is needed", fontSize = 14.sp, color = Ink.Gray, letterSpacing = 0.sp)
                        Spacer(Modifier.height(14.dp))
                        PillButton("Allow camera", true, Modifier.width(180.dp), onAsk)
                    }
                }

                Box(
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.28f))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("B&W", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp)
                }

                Box(Modifier.align(Alignment.TopEnd).padding(12.dp)) {
                    RoundButton(size = 36.dp, background = Color.White.copy(alpha = 0.28f), onClick = onFlip) {
                        FlipIcon(Color.White, 20.dp)
                    }
                }
            }

            // gallery
            Column(
                Modifier.align(Alignment.BottomStart).padding(start = 8.dp, bottom = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                RoundButton(size = 46.dp, shadow = 5.dp, onClick = onGallery) { GalleryIcon(Ink.Black, 22.dp) }
                Spacer(Modifier.height(6.dp))
                Text("Gallery", fontSize = 11.sp, color = Ink.Gray, letterSpacing = 0.sp)
            }

            // prints
            Column(
                Modifier.align(Alignment.BottomEnd).padding(end = 8.dp, bottom = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                RoundButton(size = 46.dp, shadow = 5.dp, onClick = onPrints) { StarIcon(Ink.Black, 22.dp) }
                Spacer(Modifier.height(6.dp))
                Text("Prints", fontSize = 11.sp, color = Ink.Gray, letterSpacing = 0.sp)
            }

            // shutter
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .tap(onClick = if (granted) onShutter else onAsk)
                    .size(92.dp)
                    .shadow(14.dp, CircleShape, ambientColor = Color(0x33000000), spotColor = Color(0x33000000))
                    .background(Color.White, CircleShape)
                    .padding(8.dp)
                    .clip(CircleShape)
                    .background(Ink.Black),
                contentAlignment = Alignment.Center
            ) { CameraIcon(Color.White, 28.dp, 1.8.dp) }
        }
    }
}
