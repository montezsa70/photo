package com.unclem.photobooth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

@Composable
fun LibraryScreen(
    title: String,
    files: List<File>,
    square: Boolean,
    emptyText: String,
    onBack: () -> Unit,
    onOpen: (File) -> Unit
) {
    StatusBarIcons(darkIcons = true)
    Column(
        Modifier
            .fillMaxSize()
            .background(Ink.Paper)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundButton(size = 40.dp, shadow = 4.dp, onClick = onBack) { ChevronIcon(Ink.Black, 18.dp, left = true) }
            Spacer(Modifier.width(14.dp))
            Text(
                title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                letterSpacing = (-0.5).sp, color = Ink.Black
            )
            Spacer(Modifier.weight(1f))
            Text("${files.size}", fontSize = 13.sp, color = Ink.Gray, letterSpacing = 0.sp)
        }

        if (files.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(emptyText, fontSize = 14.sp, color = Ink.Gray, letterSpacing = 0.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(if (square) 3 else 2),
                contentPadding = PaddingValues(20.dp, 6.dp, 20.dp, 24.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(files, key = { it.path }) { f -> Thumb(f, square, onOpen) }
            }
        }
    }
}

@Composable
private fun Thumb(file: File, square: Boolean, onOpen: (File) -> Unit) {
    val bmp = rememberFileBitmap(file, if (square) 400 else 900)
    Box(
        Modifier
            .fillMaxWidth()
            .tap { onOpen(file) }
            .aspectRatio(if (square) 1f else 0.6f)
            .clip(RoundedCornerShape(14.dp))
            .background(if (square) Color(0xFFE4E1DC) else Color(0xFFEAE6E0)),
        contentAlignment = Alignment.Center
    ) {
        bmp?.let {
            Image(
                it, null,
                Modifier.fillMaxSize().padding(if (square) 0.dp else 14.dp),
                contentScale = if (square) ContentScale.Crop else ContentScale.Fit
            )
        }
    }
}
