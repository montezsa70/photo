package com.unclem.photobooth

import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

@Composable
fun ResultScreen(
    file: File,
    fresh: Boolean,
    onBack: () -> Unit,
    onRetake: () -> Unit,
    onDelete: (() -> Unit)?
) {
    StatusBarIcons(darkIcons = true)
    val ctx = LocalContext.current
    val bmp = rememberFileBitmap(file, 2600)
    var saved by remember { mutableStateOf(false) }
    val slide = remember { Animatable(if (fresh) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (fresh) slide.animateTo(1f, tween(1600, easing = FastOutSlowInEasing))
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Ink.Paper)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundButton(size = 40.dp, shadow = 4.dp, onClick = onBack) { ChevronIcon(Ink.Black, 18.dp, left = true) }
            Spacer(Modifier.width(12.dp))
            Box(Modifier.size(6.dp).clip(CircleShape).background(Ink.Black))
            Spacer(Modifier.width(8.dp))
            Text(
                if (fresh) "YOUR STRIP" else "PRINT",
                fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp, color = Ink.Black
            )
            Spacer(Modifier.weight(1f))
            if (onDelete != null) {
                RoundButton(size = 40.dp, shadow = 4.dp, onClick = onDelete) { TrashIcon(Ink.Black, 20.dp) }
            }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 18.dp)
                .clip(androidx.compose.ui.graphics.RectangleShape),
            contentAlignment = Alignment.Center
        ) {
            bmp?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxHeight()
                        .aspectRatio(it.width.toFloat() / it.height.toFloat())
                        .graphicsLayer { translationY = -(1f - slide.value) * size.height }
                        .shadow(10.dp, ambientColor = Color(0x33000000), spotColor = Color(0x33000000))
                )
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PillButton(if (saved) "Saved" else "Save to Photos", true, Modifier.weight(1f)) {
                if (!saved) {
                    val ok = Store.exportToGallery(ctx, file)
                    saved = ok
                    Toast.makeText(
                        ctx,
                        if (ok) "Saved to Pictures/PhotoBooth" else "Couldn't save",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            PillButton("Share", false, Modifier.weight(1f)) { Store.share(ctx, file) }
        }
        if (fresh) {
            Box(
                Modifier.fillMaxWidth().tap(onClick = onRetake).padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Take again", fontSize = 14.sp, color = Ink.Gray, letterSpacing = 0.sp)
            }
        } else {
            Spacer(Modifier.height(16.dp))
        }
    }
}
