package com.unclem.photobooth

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import java.io.File

sealed interface Screen {
    data object Home : Screen
    data object Session : Screen
    data object Gallery : Screen
    data object Prints : Screen
    data class Result(val file: File, val fresh: Boolean, val origin: Screen) : Screen
}

@Composable
fun PhotoBoothApp() {
    val context = LocalContext.current
    val holder = remember { CameraHolder() }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var front by remember { mutableStateOf(true) }
    var version by remember { mutableIntStateOf(0) }
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
    }
    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(Manifest.permission.CAMERA)
    }
    DisposableEffect(Unit) { onDispose { holder.executor.shutdown() } }

    BackHandler(enabled = screen != Screen.Home) {
        val s = screen
        screen = if (s is Screen.Result) s.origin else Screen.Home
    }

    when (val s = screen) {
        Screen.Home -> HomeScreen(
            holder = holder,
            front = front,
            granted = granted,
            onFlip = { front = !front },
            onAsk = { launcher.launch(Manifest.permission.CAMERA) },
            onShutter = { screen = Screen.Session },
            onGallery = { screen = Screen.Gallery },
            onPrints = { screen = Screen.Prints }
        )

        Screen.Session -> SessionScreen(
            holder = holder,
            front = front,
            onClose = { screen = Screen.Home },
            onDone = { file ->
                version++
                screen = Screen.Result(file, true, Screen.Home)
            }
        )

        Screen.Gallery -> {
            val files = remember(version) { Store.shots(context) }
            LibraryScreen(
                title = "Gallery",
                files = files,
                square = true,
                emptyText = "No photos yet",
                onBack = { screen = Screen.Home },
                onOpen = { screen = Screen.Result(it, false, Screen.Gallery) }
            )
        }

        Screen.Prints -> {
            val files = remember(version) { Store.prints(context) }
            LibraryScreen(
                title = "Prints",
                files = files,
                square = false,
                emptyText = "No prints yet",
                onBack = { screen = Screen.Home },
                onOpen = { screen = Screen.Result(it, false, Screen.Prints) }
            )
        }

        is Screen.Result -> ResultScreen(
            file = s.file,
            fresh = s.fresh,
            onBack = { screen = s.origin },
            onRetake = { screen = Screen.Session },
            onDelete = if (s.fresh) null else {
                {
                    s.file.delete()
                    version++
                    screen = s.origin
                }
            }
        )
    }
}
