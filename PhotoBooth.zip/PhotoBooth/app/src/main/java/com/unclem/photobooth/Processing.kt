package com.unclem.photobooth

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import java.util.Random
import kotlin.math.min

/** Turns a raw camera frame into a square, contrasty, grainy black & white portrait. */
object Booth {
    const val FRAME = 900

    fun develop(src: Bitmap, mirror: Boolean, size: Int = FRAME): Bitmap {
        val side = min(src.width, src.height)
        val sx = (src.width - side) / 2f
        val sy = (src.height - side) / 2f
        val scale = size.toFloat() / side

        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)

        val m = Matrix().apply {
            postTranslate(-sx, -sy)
            postScale(if (mirror) -scale else scale, scale)
            if (mirror) postTranslate(size.toFloat(), 0f)
        }

        val c = 1.22f
        val t = 128f * (1f - c) + 4f
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(
            ColorMatrix(
                floatArrayOf(
                    c * .299f, c * .587f, c * .114f, 0f, t,
                    c * .299f, c * .587f, c * .114f, 0f, t,
                    c * .299f, c * .587f, c * .114f, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        canvas.drawBitmap(src, m, paint)

        // soft vignette
        val vignette = Paint().apply {
            shader = RadialGradient(
                size / 2f, size / 2f, size * 0.75f,
                intArrayOf(0x00000000, 0x00000000, 0x66000000),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), vignette)

        addGrain(out, 30)
        return out
    }

    private fun addGrain(bmp: Bitmap, amount: Int) {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val rnd = Random()
        for (i in px.indices) {
            val v = px[i] and 0xFF
            val n = (rnd.nextGaussian() * amount * 0.55).toInt()
            val g = (v + n).coerceIn(0, 255)
            px[i] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }
}

/** Stitches developed frames into a vertical photobooth strip on off-white paper. */
object Strip {
    fun compose(photos: List<Bitmap>, date: String): Bitmap {
        val f = Booth.FRAME
        val margin = 70
        val gap = 40
        val footer = 250
        val n = photos.size
        val w = f + margin * 2
        val h = margin + n * f + (n - 1) * gap + footer

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)

        val bg = Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                Color.parseColor("#F8F5F0"), Color.parseColor("#ECE7E0"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)

        val hairline = Paint().apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = Color.parseColor("#22000000")
        }
        photos.forEachIndexed { i, p ->
            val x = margin.toFloat()
            val y = (margin + i * (f + gap)).toFloat()
            canvas.drawBitmap(p, x, y, null)
            canvas.drawRect(x, y, x + f, y + f, hairline)
        }

        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#111111")
            textSize = 44f
            letterSpacing = 0.28f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }
        val sub = Paint(title).apply {
            color = Color.parseColor("#8C8883")
            textSize = 30f
            letterSpacing = 0.2f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val base = (margin + n * f + (n - 1) * gap + 112).toFloat()
        canvas.drawText("PHOTO BOOTH", w / 2f, base, title)
        canvas.drawText(date, w / 2f, base + 64f, sub)
        return out
    }
}
